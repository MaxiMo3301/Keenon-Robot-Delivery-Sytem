#! /usr/bin/env python
#coding=utf-8

# import module
import rospy

from std_msgs.msg import String

def heartBeating():

    pub = rospy.Publisher('/asa_heartbeat', String, queue_size=10)

    rate = rospy.Duration(10, 0) # 10 second 

    while not rospy.is_shutdown():

        message = "RosBridge Status: True. The Reported Time is: %s" % rospy.get_time()

        rospy.loginfo(message)

        pub.publish(message)

        rospy.sleep(rate)     

# Main for testing
if __name__ == '__main__':

    rospy.init_node('asa_report')

    try:

        #rospy.init_node('heartbeat_msg')

        heartBeating()

    except rospy.ROSInterruptException:
        pass