#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import time
import json

# import msg

from sensor_msgs.msg import BatteryState
from std_msgs.msg import Bool, String
from keenon_charge_msgs.msg import ChargeFB

class asaStatus:

    def __init__(self):

        self.publisher = rospy.Publisher('/asa_status_report', String, queue_size=10)
        self._battery = None
        self._ub_status = None
        self._ch_status = None
        self.rate = rospy.Duration(1, 0) # 1 second 


    def publish_msg(self):

        msg = { 
            "battery_percentage": self._battery,
            "urgency_button_status": self._ub_status,
            "charge_state": self._ch_status
        }

        msg = json.dumps(msg)

        if (self._battery != None and self._ub_status != None and self._ch_status != None):
            rospy.loginfo(msg)
            self.publisher.publish(msg)

    def battery_callback(self, data):

        self._battery = data.percentage

        self.publish_msg()


    def ub_callback(self, data):

        self._ub_status = data.data

        self.publish_msg()

    def ch_callback(self, data):

        self._ch_status = data.state

        self.publish_msg()


    def talker(self):

        while not rospy.is_shutdown():

            rospy.Subscriber('/battery_state', BatteryState, self.battery_callback)

            rospy.Subscriber('/urgency_button_status', Bool, self.ub_callback)

            rospy.Subscriber('/charge_state_fromSTM32', ChargeFB, self.ch_callback)

            rospy.sleep(self.rate)


if __name__ == "__main__":

    rospy.init_node('asa_status')

    try:
        status = asaStatus()

        status.talker()

    except rospy.ROSInterruptException:
        pass
