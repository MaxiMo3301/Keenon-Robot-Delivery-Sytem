#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import asa_move_base
import asa_exit_lift
import asa_enter_lift
import asa_move_coor

# import ros service

from asa_delivery.srv import AsaEnterLift, AsaExitLift, AsaMoveBase, AsaMoveCoor


# receive call and send to enter_lift function
def enter_Lift(req):

    print(req)

    enterGoal, enterLift = asa_enter_lift.enter_lift_schedule(req.floor)

    print(enterGoal, enterLift)

    return enterLift, enterGoal


# receive call and send to exit lidt function
def exit_Lift(req):

    exitL, InL = asa_exit_lift.quit_lift(req.floor)

    return InL, exitL


# receive string input and send to asa_move_base server
def move_base(req):

    success = asa_move_base.asa_move_srv(req.floor, req.goal)

    return success

# receive float input and send yo asa_move_to_coor server
def move_coor(req):

    arrive = asa_move_coor.asa_coor_srv(req.x_coor, req.y_coor, req.z_coor, req.w_coor)

    return arrive

if __name__ == "__main__":

    # create node asa_move_base"
    rospy.init_node("asa_move_base")

    # create service lift_enter for external call
    rospy.Service('/asa_move_base/lift_enter', AsaEnterLift, enter_Lift)

    # create service lift_exit for external call    
    rospy.Service('/asa_move_base/lift_exit', AsaExitLift, exit_Lift)

    # create service move_to_pose for external call
    rospy.Service('/asa_move_base/move_to_pose', AsaMoveBase, move_base)

    # create service move_to_coor for external call
    rospy.Service('/asa_move_base/move_to_coor', AsaMoveCoor, move_coor)

    rospy.loginfo("Lift Control Server started.")

    rospy.spin()
