#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import time
import sys
import os
import yaml
import actionlib
import rosparam
import math
import subprocess
import asa_pose

from asa_cancel import cancelGoal

# import ros msg
from std_srvs.srv import Empty
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped
from keenon_move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import GoalID

def goalCancel():

    nullGoal = cancelGoal()

    nullGoal.sendCancel()

def get_pose_data(x, y, z, w):

    # Create Array

    pose = []

    # load the posistiob data

    pose.append(
        (
            x,
            y,
            z,
            w   
        )
    )

    print(x, y, z, w)

    return pose

def move(pose):

    # Create a new goal with MoveBaseGoal constructor

    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "map"
    goal.target_pose.header.stamp = rospy.Time.now()

    # X,Y,Z coor data

    goal.target_pose.pose.position.x = pose[0][0]
    goal.target_pose.pose.position.y = pose[0][1]
    goal.target_pose.pose.position.z = 0.0

    # X,Y,Z,W orientation

    goal.target_pose.pose.orientation.x = 0.0
    goal.target_pose.pose.orientation.y = 0.0
    goal.target_pose.pose.orientation.z = pose[0][2]
    goal.target_pose.pose.orientation.w = pose[0][3]

    print(goal)

    return(goal)


    # asa_move_base
def asa_move_coor(x, y, z, w, timeout):

    # action client
    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)

    client.wait_for_server()

    # load the goal's pose from the database
    pose = get_pose_data(x, y, z, w)

    # send goal to move_base    
    goal = move(pose)

    client.send_goal(goal)
    wait = client.wait_for_result(timeout=rospy.Duration(timeout))

    if wait == True:

        resultCheck = client.get_result()

        if resultCheck.ret_status == 1:

            return True

        else:

            return False

    else:

        return False

# create callback for the move_to_pose service call
def asa_coor_srv(x, y, z, w):

    success = asa_move_coor(x, y, z, w, 120) 

    if success == True:

        return True

    else:

        goalCancel()

        return False


if __name__ == "__main__":
    rospy.init_node("asa_delivery_server")

    result = asa_move_srv(0.02, 0.06, -0.005, 0.999)

    print(result)

    rospy.spin()
