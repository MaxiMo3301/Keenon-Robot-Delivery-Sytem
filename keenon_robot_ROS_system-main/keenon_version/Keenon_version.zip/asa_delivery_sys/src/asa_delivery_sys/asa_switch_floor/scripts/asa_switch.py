#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import os
import yaml

# import msg

from asa_switch_floor.srv import AsaSwitchFloor
from keenon_nav_msgs.srv import SwitchMap
from geometry_msgs.msg import Pose
def get_pose_tag(floor):

    map_folder = os.path.abspath('/asa_delivery_sys/src/asa_delivery_sys/asa_delivery/scripts/testing.yaml')
    with open(map_folder) as f:
        yaml_desc = yaml.safe_load(f)
    
    pose_tag = Pose()

    pose_tag.position.x = yaml_desc[floor]["goal"]["x"]
    pose_tag.position.y = yaml_desc[floor]["goal"]["y"]
    pose_tag.orientation.z = yaml_desc[floor]["goal"]["z"]
    pose_tag.orientation.w = yaml_desc[floor]["goal"]["w"]

    return pose_tag


def switch_map(req):

    # create service proxy to call the keenon switch map

    switch_map_service = rospy.ServiceProxy('/switch_dest_floor_map', SwitchMap)

    # get the pose tag from the yaml file

    pose_tag_current = get_pose_tag(req.currentFloor)
    pose_tag_next = get_pose_tag(req.nextFloor)

    # call the keenon switch map service with the floor and pose tags

    result = switch_map_service(req.nextFloor, pose_tag_current, pose_tag_next)

    return result.result



if __name__ == "__main__":

    # create node asa_switch_map
    rospy.init_node("asa_switch_map")

    #create service goCharge for external call
    rospy.Service('/asa_switch_map/switchFloor', AsaSwitchFloor, switch_map)

    rospy.spin()
