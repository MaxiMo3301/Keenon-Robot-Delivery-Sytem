#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import asa_heartbeat
from asa_status import asaStatus


if __name__ == '__main__':

    #create node asa_report
    rospy.init_node('asa_report')

    try:

        status = asaStatus()

        status.talker()

        heartbeat = asa_heartbeat.heartBeating()

    except rospy.ROSInterruptException:

        pass