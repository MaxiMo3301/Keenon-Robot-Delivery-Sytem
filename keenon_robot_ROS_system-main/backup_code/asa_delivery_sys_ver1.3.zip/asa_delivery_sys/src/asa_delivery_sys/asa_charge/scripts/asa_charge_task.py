#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import actionlib

from asa_charge_state import charge_state

# import msg

from actionlib_msgs.msg import GoalID

from asa_charge.srv import AsaChargeTask, AsaLeftCharge

from keenon_charge_msgs.msg import ChargeTaskGoal, ChargeTaskAction, ChargeFB


def chargeStatus():

    checkChargeState = charge_state()

    status = checkChargeState.charge_status()

    return status

def cancelCharge():

    cancel = rospy.Publisher("/charge_task/cancel", GoalID, queue_size=1)

    cancelMsg = GoalID()

    counter = cancel.publish(cancelMsg)

    if not counter:

        return False
    else:
        return True

def charge_task(req):

    # create action client to passing the type to the action
    # keenon_charge to the constructor.

    client = actionlib.SimpleActionClient('charge_task', ChargeTaskAction)

    # Waits until the action server has started up and started
    # listening for goals.

    client.wait_for_server()

    # Create a goal to send to the action server.
    goal = ChargeTaskGoal()

    goal.goal_type = 1

    # Create the goal to the action server.

    client.send_goal(goal)

    # Check the charge status of the robot

    status = chargeStatus()

    if not status:
        cancelCharge()
        return False
    else:
        return True

def left_charge(req):

    client = actionlib.SimpleActionClient('charge_task', ChargeTaskAction)

    client.wait_for_server()

    goal = ChargeTaskGoal()

    goal.goal_type = 3

    client.send_goal(goal)
    
    wait = client.wait_for_result()

    if not wait:

        return False
    
    else:

        return True

if __name__ == "__main__":

    # create node asa_charge_task
    rospy.init_node("asa_charge_task")

    #create service goCharge for external call
    rospy.Service('/asa_charge_task/goCharge', AsaChargeTask, charge_task)

    rospy.Service('/asa_charge_task/leftCharge', AsaLeftCharge, left_charge)

    rospy.spin()
