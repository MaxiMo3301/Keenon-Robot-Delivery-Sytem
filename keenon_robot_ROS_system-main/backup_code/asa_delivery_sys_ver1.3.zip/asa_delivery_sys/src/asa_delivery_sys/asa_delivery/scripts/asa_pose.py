#! /usr/bin/env python
#coding=utf-8

# Modules
import rospy
import os
import yaml
import math

# Ros Message
from geometry_msgs.msg import PoseWithCovarianceStamped , PoseStamped



# Class : Robot's Position Report
class pos_check:

    # Var
    x_pos = None
    y_pos = None
    msg = None

    # Function - get pose data
    def PoseCallBack(self, msg):
        self.msg = msg

        # Position Information from Subscribing  - 
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        self.x_pos = x
        self.y_pos = y

        sub.unregister()

    # Function - Subscribing to AMCL_POSE
    def PoseSub(self):

    #     rospy.init_node('pose_sub', anonymous=False)

        # Keep tracking /localization/robot_pose and callback the data
        global sub
        sub = rospy.Subscriber('/localization/robot_pose', PoseWithCovarianceStamped, self.PoseCallBack)
    #     rospy.spin()

    # check the currrnt pose
    def pose_check(self, value):

        self.PoseSub()

        while (True):
            if (self.x_pos != None and self.y_pos != None):
                # TODO - replace map folder with DB

                map_folder = os.path.abspath('/asa_delivery_sys/src/asa_delivery_sys/asa_delivery/scripts/Lift.yaml')

                with open(map_folder) as f:

                    yaml_desc = yaml.safe_load(f)
                
                # get the X coordinate of the zone
                x1 = yaml_desc[value]['x1']
                x2 = yaml_desc[value]['x2']
                x3 = yaml_desc[value]['x3']
                x4 = yaml_desc[value]['x4']

                # get the Y coordinate of the zone
                y1 = yaml_desc[value]['y1']
                y2 = yaml_desc[value]['y2']
                y3 = yaml_desc[value]['y3']
                y4 = yaml_desc[value]['y4']

                print(x1, x2, x3, x4, y1, y2, y3, y4)

                # compare the coordinate with the robot and the zone

                if self.x_pos > x3 and self.x_pos < x2 and self.y_pos > y2 and self.y_pos < y3:

                    return True
                else:
                    
                    return False
            



# if __name__ == '__main__':
#     try:
#         pos_check.PoseSub()
#     except:
#         rospy.loginfo("Error")
