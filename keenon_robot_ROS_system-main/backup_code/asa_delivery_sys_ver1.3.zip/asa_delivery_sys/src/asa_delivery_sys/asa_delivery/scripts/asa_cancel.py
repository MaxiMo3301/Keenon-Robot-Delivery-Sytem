#! /usr/bin/env python
#coding=utf-8

# import module

import rospy

# import msg

from actionlib_msgs.msg import GoalID

# Cancel move base goal

class cancelGoal:

    def sendCancel(self):

        self.cancel = rospy.Publisher("/move_base/cancel", GoalID, queue_size=1)

        cancelMsg = GoalID()

        counter = self.cancel.publish(cancelMsg)

        if not counter:

            rospy.logerr("Error: Can't cancel goal.")
            return False

        else:

            rospy.loginfo("Success: Move Base Goal is now canceled.")
            return True

if __name__ == "__main__":

    rospy.init_node("cancel_goal")
    server = cancelGoal()
    
    server.sendCancel()

    rospy.spin()
