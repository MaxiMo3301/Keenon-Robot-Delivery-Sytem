#! /usr/bin/env python
#coding=utf-8

# Modules
import rospy
import os
import yaml
import math

# Ros Message 
from geometry_msgs.msg import PoseWithCovarianceStamped , PoseStamped


# Class : Robot's Position Report
class curr_pos:

    def __init__(self):

        self.x_pose = None
        self.y_pose = None
        self.z_pose = None
        self.w_pose = None
        self.angle  = (math.pi) / 6 
        self.msg = None
        
    # Function - get pose data:
    def currCallBack(self, data):

        # load data from subed topic 

        self.msg = data

        # get coord from data

        self.x_pose = self.msg.pose.pose.position.x
        self.y_pose = self.msg.pose.pose.position.y 
        self.z_pose = self.msg.pose.pose.orientation.z
        self.w_pose = self.msg.pose.pose.orientation.w

    # check the curr position

    def currPoseCheck(self, x, y, z, w):

        self.sub = rospy.Subscriber('/localization/robot_pose', PoseWithCovarianceStamped, self.currCallBack)

        while True:

            if self.x_pose != None and self.y_pose != None:


                # set limit for w pose    
                if self.w_pose > 1:

                    self.w_pose = 1

                elif self.w_pose < -1:

                    self.w_pose = -1

                # set limit for z pose
                if self.z_pose > 1:

                    self.z_pose = 1

                elif self.z_pose < -1:

                    self.z_pose = -1

                # calculate thetha 
                thetha_w = 2 * math.acos(w)

                thetha_z = 2 * math.asin(z)

                thetha_w_pose = 2 * math.acos(self.w_pose)

                thetha_z_pose = 2 * math.asin(self.z_pose)

                """print(thetha_z, thetha_w)

                print(thetha_z_pose, thetha_w_pose)

                print(thetha_z_pose - self.angle, thetha_w_pose - self.angle)

                print(thetha_z_pose + self.angle, thetha_w_pose + self.angle)"""


                if (x > self.x_pose -0.15 and x < self.x_pose + 0.15) and (y > self.y_pose - 0.15 and y < self.y_pose + 0.15) and (thetha_z >= thetha_z_pose - self.angle and thetha_z <= thetha_z_pose + self.angle) and (thetha_w >= thetha_w_pose - self.angle and thetha_w <= thetha_w_pose + self.angle):

                    return True
                else:

                    return False
                
# main

if __name__ == "__main__":

    rospy.init_node("asa_pose_data", anonymous= True)

    try:

        pose = curr_pos()

        #result = pose.currPoseCheck(2.58050630746, 1.09674958533, -0.698444445949, 0.715665562159)

        result = pose.currPoseCheck(3.50706354667, 1.2000664596, 0.707087781409, 0.707126509748)

        print(result)

    except:

        rospy.loginfo("Error")
