#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import time
import sys
import os
import yaml
import actionlib
import rosparam
import math
import subprocess
import asa_move_base

from asa_pose import pos_check

from asa_cancel import cancelGoal

# import ros msg
from std_srvs.srv import Empty
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped
from actionlib_msgs.msg import GoalID


# Lift - from inside go to waiting zone
def check_pose(floor):

    tracking = pos_check()

    inLift = tracking.pose_check(floor)

    return inLift

def Goalcancel():

    nullGoal = cancelGoal()

    nullGoal.sendCancel()

def quit_lift(floor):

    exitLift = asa_move_base.asa_move_base(floor, "waiting_zone", 25)

    isInLift = check_pose(floor)

    Goalcancel()

    return exitLift, isInLift



if __name__ == "__main__":

    rospy.init_node("Lift_Exit")

    success = quit_lift(5)

    print(success)

    rospy.spin()
