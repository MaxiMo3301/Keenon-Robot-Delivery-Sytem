#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import time

# import ros msg

from keenon_charge_msgs.msg import ChargeFB

class charge_state:

    status = None

    def charge_callback(self, data):

        self.data = data

        self.status = data.state


    # Define timeout for checking the current state
    def charge_now(self):

        timelimit = 20

        start = time.time()

        while True:

            time.sleep(0.1)

            remaining = timelimit + start - time.time()

            print(remaining)

            if self.status == 53:

                sub.unregister()
                return True

            if remaining <= 0:
                break

        return False


    def charge_status(self):

        global sub

        sub = rospy.Subscriber("/charge_state_fromSTM32", ChargeFB, self.charge_callback)

        while True:

            if self.status != None:
                
                counter = self.charge_now()


                if not counter:

                    sub.unregister()
                    return False
                else:
                    return True




if __name__ == "__main__":

    rospy.init_node("sub_test")

    server = charge_state()

    counter = server.charge_status()

    print(counter)

    rospy.spin()