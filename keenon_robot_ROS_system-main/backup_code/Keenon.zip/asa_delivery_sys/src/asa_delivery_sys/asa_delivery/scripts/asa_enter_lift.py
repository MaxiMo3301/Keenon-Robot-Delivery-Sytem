#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import asa_move_base
import asa_exit_lift

from asa_pose import pos_check

# import msg

from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped

# Lift_schedule
def enter_lift_schedule(floor):

    isInGoal = False
    isInLift = True

    # create pos_check instant 

    tracking = pos_check()

    # Step 1: from waiting zoom enter lift's searching zoom
    inGoal = asa_move_base.asa_move_base(floor, "goal", 25)

    if not inGoal:
        isInGoal = False
    elif inGoal:
        isInGoal = True
        isInLift = tracking.pose_check(floor)


    # Sub Step: if step 1 or step 3 failed, back to lobby waiting zone
    if isInGoal ==  False:
        exitLift , isInLift =  asa_exit_lift.quit_lift(floor)
    
        
    # return counter to the server

    return isInGoal, isInLift
   


if __name__ == "__main__":

    rospy.init_node("Lift_Enter")

    status = enter_lift_schedule(5)

    print(status)

    rospy.spin()
