#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import asa_move_base
import asa_exit_lift
import asa_enter_lift

# import ros service

from asa_delivery.srv import AsaEnterLift, AsaExitLift, AsaMoveBase


# receive call and send to enter_lift function
def enter_Lift(req):

    print(req)

    enterGoal, enterLift = asa_enter_lift.enter_lift_schedule(req.floor)

    print(enterGoal, enterLift)

    return enterLift, enterGoal


# receive call and send to exit lidt function
def exit_Lift(req):

    exitL, InL = asa_exit_lift.quit_lift(req.floor)

    return InL, exitL


# receive string input and send to asa_move_base server
def move_base(req):

    success = asa_move_base.asa_move_srv(req.floor, req.goal)

    return success

if __name__ == "__main__":

    # create node asa_move_base"
    rospy.init_node("asa_move_base")

    # create service lift_enter for external call
    rospy.Service('/asa_move_base/lift_enter', AsaEnterLift, enter_Lift)

    # create service lift_exit for external call
    rospy.Service('/asa_move_base/lift_exit', AsaExitLift, exit_Lift)

    # create service move_to_pose for external call
    rospy.Service('/asa_move_base/move_to_pose', AsaMoveBase, move_base)

    rospy.loginfo("Lift Control Server started.")

    rospy.spin()
