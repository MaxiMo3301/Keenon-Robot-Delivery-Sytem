#! /usr/bin/env python
#coding=utf-8

# import module

import rospy
import time
import sys
import os
import yaml
import actionlib
import rosparam
import math
import subprocess
import asa_pose

from asa_cancel import cancelGoal

# import ros msg
from std_srvs.srv import Empty
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped
from keenon_move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import GoalID

def load_building_desc( ):

    # TODO - replace map folder with DB

    map_folder = os.path.abspath('/home/peanut/asa_delivery_sys/src/asa_delivery_sys/asa_delivery/scripts/testing.yaml')

    with open(map_folder) as f:
        yaml_desc = yaml.safe_load(f)

    return yaml_desc

def goalCancel():

    nullGoal = cancelGoal()

    nullGoal.sendCancel()

def get_pose_data(floor, goal, database):

    # Create Array

    pose = []

    # load the posistiob data

    x = database[floor][goal]["x"]
    y = database[floor][goal]["y"]
    z = database[floor][goal]["z"]
    w = database[floor][goal]["w"]

    pose.append(
        (
            x,
            y,
            z,
            w   
        )
    )

    print(x, y, z, w)

    return pose

def move(pose):

    # Create a new goal with MoveBaseGoal constructor

    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "map"
    goal.target_pose.header.stamp = rospy.Time.now()

    # X,Y,Z coor data

    goal.target_pose.pose.position.x = pose[0][0]
    goal.target_pose.pose.position.y = pose[0][1]
    goal.target_pose.pose.position.z = 0.0

    # X,Y,Z,W orientation

    goal.target_pose.pose.orientation.x = 0.0
    goal.target_pose.pose.orientation.y = 0.0
    goal.target_pose.pose.orientation.z = pose[0][2]
    goal.target_pose.pose.orientation.w = pose[0][3]

    print(goal)

    return(goal)


    # asa_move_base
def asa_move_base(floor, value, timeout):

    # action client
    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)

    client.wait_for_server()

    # loading the data of building
    building_description = load_building_desc()

    # load the goal's pose from the database
    pose = get_pose_data(floor, value, building_description)

    # send goal to move_base    
    goal = move(pose)

    client.send_goal(goal)

    wait = client.wait_for_result(timeout=rospy.Duration(timeout))


    if not wait:

        return False
    
    else:
            
        return True

# create callback for the move_to_pose service call
def asa_move_srv(floor, value):

    success = asa_move_base(floor, value, 20)

    return success



if __name__ == "__main__":
    rospy.init_node("asa_delivery_server")

    goal = raw_input("Enter Goal: ")

    success = asa_move_base(5 ,goal, 20)

    print(success)

    rospy.spin()
