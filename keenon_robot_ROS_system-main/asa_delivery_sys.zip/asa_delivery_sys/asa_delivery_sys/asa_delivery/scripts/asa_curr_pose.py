#! /usr/bin/env python
#coding=utf-8

# Modules
import rospy
import os
import yaml
import math

# Ros Message 
from geometry_msgs.msg import PoseWithCovarianceStamped , PoseStamped


# Class : Robot's Position Report
class curr_pos:

    def __init__(self):

        self.x_pose = None
        self.y_pose = None
        self.msg = None
        
    # Function - get pose data:
    def currCallBack(self, data):

        # load data from subed topic 

        self.msg = data

        # get coord from data

        self.x_pose = self.msg.pose.pose.position.x
        self.y_pose = self.msg.pose.pose.position.y 


    # check the curr position

    def currPoseCheck(self, x, y):

        self.sub = rospy.Subscriber('/localization/robot_pose', PoseWithCovarianceStamped, self.currCallBack)

        while True:

            if self.x_pose != None and self.y_pose != None:

                if (x > self.x_pose -0.1 and x < self.x_pose + 0.1) and (y > self.y_pose - 0.1 and y < self.y_pose + 0.1):

                    return True
                else:

                    return False
                
# main

if __name__ == "__main__":

    rospy.init_node("asa_pose_data", anonymous= True)

    try:

        pose = curr_pos()

        result = pose.currPoseCheck(2.58050630746, 1.09674958533)

        print(result)

    except:

        rospy.loginfo("Error")